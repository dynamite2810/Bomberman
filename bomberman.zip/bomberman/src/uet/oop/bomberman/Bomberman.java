package uet.oop.bomberman;

import uet.oop.bomberman.exceptions.BombermanException;
import uet.oop.bomberman.gui.Frame;
import uet.oop.bomberman.sound.Sound;


public class Bomberman {
	
	public static void main(String[] args) throws BombermanException {
		Sound.play("soundtrack");
		Frame mainwindow = new Frame();
	}
}
