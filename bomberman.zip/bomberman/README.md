# Bomberman game

Made for the POO class in ISEL

![Bomberman](bomber.png)